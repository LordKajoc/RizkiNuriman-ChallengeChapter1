package Latihan4Jenis
fun main(){
    //Nomor 2
    var kotak = rectangle(5,5)
    kotak.getArea()
}
//Class rectabgle dengan property width dan length
class rectangle (var width:Int, var height:Int){
    //Methode getArea yang mengembalikan luas persegi panjang width x lebar
    fun getArea():Int{
        return width*height
    }
}
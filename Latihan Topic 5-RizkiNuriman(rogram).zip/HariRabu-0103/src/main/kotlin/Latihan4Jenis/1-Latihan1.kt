package Latihan4Jenis

fun main() {
    //Nomor 1
    var person = Person("Rizki", 12)
    person.introduce()
}

//Class person dengan property nama dan age
class Person(var name: String, var age: Int) {
    //method introduce yang mencetak pesan sesuai dengan nilai property
    fun introduce() {
        println("Hi, my name is $name and I am $age years old.!")
    }
}
package Latihan4Jenis
fun main(){
    //Nomor 3
    var animal = Animal("ayam","wkwkwk")
    animal.makesound()
}

//Class Animal Dengan property name dan sound
class Animal(var name :String, var sound:String){
    //method makesound yang mencetak pesan dari kedua property
    fun makesound(){
        println("$name says $sound")
    }
}







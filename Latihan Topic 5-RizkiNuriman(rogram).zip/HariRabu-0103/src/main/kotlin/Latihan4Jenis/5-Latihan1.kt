package Latihan4Jenis
fun main(){
    //Nomor 5
    var mobil = Car()
    println(mobil.drive())
    var motor = Motorcycle()
    println(motor.drive())
}

//Class Parent vehicle dengan atribut merk dan warna
open class Vehicle(var merk :String, var warna:String){
    //methode drive yang akan diimplementasikan dan mengembalikan nilai string seseuai nilai dari atribut
    open fun drive():String{
        return "Driving $merk"
    }
}
//Class Child Car dan Motorcycleyang merupakan turunan dari Class Parent Vehicle
class Car: Vehicle("Yamaha", "Merah"){
    override fun drive(): String {
        return super.drive()
    }
}
class Motorcycle :Vehicle("Honda", "Biru"){
    override fun drive(): String {
        return super.drive()
    }
}
package Latihan4Jenis

fun main() {
    //Nomor 4
    var siswa = Student("Kelas Android", "Nilai Memuaskan")
    println(siswa.getDetail())
}

//parent class person
open class person4(var nama: String, var umur: String)

//child class Student
class Student(var kelas: String, var nilai: String) : person4("Rizki", "21 Tahun") {
    fun getDetail(): String {
        return """$nama $kelas $umur $nilai
        """.trimMargin()
    }
}
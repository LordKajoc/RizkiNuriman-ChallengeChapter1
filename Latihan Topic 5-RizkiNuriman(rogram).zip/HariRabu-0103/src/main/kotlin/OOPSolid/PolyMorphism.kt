package OOPSolid

fun main(){
    val buah = Buah()
    buah.deskripsi("Mangga")
    buah.deskripsi("Apel", "C")
}

class Buah (){
    fun deskripsi(name:String){
        println("Nama Buah: $name")
    }
    fun deskripsi(name: String, Vit:String){
    }
}
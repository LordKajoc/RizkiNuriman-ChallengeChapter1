package OOPSolid

//Enkapsulasi
open class Mahasiswa() {
    var name: String = "Dwiki"
    private var age: Int = 21 //hanya dapat diakses di Class ini Saja
    open protected var address: String ="Bandung" // class dan sub class
    internal var nim :String ="83675" //class yang sama/1 project

    fun examplepublic(){

    }
}

class AndroidClass():Mahasiswa(){
    override var address: String
        get() = super.address
        set(value) {}
}

fun main() {
    val mhs = Mahasiswa()
    println(mhs.nim)

}

class classbiasa(){
    fun examplepublic(){
    }
    private fun exampleprivate(){}
    protected fun exProtected(){}
    internal fun  exinternal(){
    }
}

private class kelassaya(){

}

internal class kelaskamu(){

}


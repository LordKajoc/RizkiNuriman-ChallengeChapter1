package OOPSolid

//Tidak bisa dibikinkan objek
abstract class Dosen(){
    abstract fun namadosen()
    fun jumlahmatkulajar(){
        println("jumlah matkul ajar = 2")
    }
}
class matkul():Dosen(){
    override fun namadosen() {
        println("Nama Dosen: Andika")
    }
}

class mobil:Dosen(){
    override fun namadosen() {
        TODO("Not yet implemented")
    }
}
fun main(){
    var namadosen = matkul()
    namadosen.namadosen()
    namadosen.jumlahmatkulajar()
}
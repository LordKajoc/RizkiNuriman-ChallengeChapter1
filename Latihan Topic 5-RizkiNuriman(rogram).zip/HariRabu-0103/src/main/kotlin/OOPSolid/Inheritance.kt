package OOPSolid

import java.util.NavigableMap

//Pewarisan

open class Animal (){
    open fun deskripsi(){
        println("Deskripsi Hewan")
    }
    open fun namaAnimal (nama:String){
        println("nama binatang: $nama")
    }
}

open class Harimau : Animal(){
    open override fun deskripsi() {
        super.deskripsi()
    }

    open override fun namaAnimal(nama: String) {
        super.namaAnimal(nama)
    }

    fun WarnaKulit(){
        println("Putih")
    }
}

class Gajah: Harimau(){
    override fun deskripsi() {
        super.deskripsi()
    }

    override fun namaAnimal(nama: String) {
        super.namaAnimal(nama)
    }
}